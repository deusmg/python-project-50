### Hexlet tests and linter status:
[![Actions Status](https://github.com/deusmg/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/deusmg/python-project-50/actions)
[![Build Status](https://github.com/deusmg/python-project-50/workflows/gendiff_check/badge.svg)](https://github.com/deusmg/python-project-50/actions)