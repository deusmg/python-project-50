### Hexlet tests and linter status:
[![Actions Status](https://github.com/deusmg/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/deusmg/python-project-50/actions)
[![Build Status](https://github.com/deusmg/python-project-50/workflows/gendiff_check/badge.svg)](https://github.com/deusmg/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8ca69b5894972436abcf/maintainability)](https://codeclimate.com/github/deusmg/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/8ca69b5894972436abcf/test_coverage)](https://codeclimate.com/github/deusmg/python-project-50/test_coverage)