import json


def json_format(diff_result):
    return json.dumps(diff_result)
